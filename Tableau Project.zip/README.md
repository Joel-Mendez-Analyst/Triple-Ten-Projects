[Analyzing Superstore Return Rates and Trends Story](https://www.loom.com/share/84783e2ff67d4179856dfbf096833cf2?sid=f300094b-a869-41bb-b43b-58dc4990fb06)



[Joel Mendez - Data Story Telling Project](https://public.tableau.com/app/profile/joel.mendez1938/viz/JoelMendez-DataStoryTellingProject/ReturnRateAnalysis)

